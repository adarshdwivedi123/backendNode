// https://github.com/apni-coding/Todo-List-Using-React?tab=readme-ov-file

const express=require('express');
const app=express();
const cors = require('cors') 

require("dotenv").config();
const PORT=process.env.PORT || 4000;

app.use(express.json());
app.use(cors()); 
const todoRoutes=require("./routes/route");
console.log(todoRoutes);
app.use("/api/v1",todoRoutes);

//server strt
app.listen(PORT,()=>{
    console.log(`Server Started succesfully at ${PORT}`);

})

// Db conneciton
const dbConnect=require("./config/database");
dbConnect();


// default routes
app.get("/",(req,res)=>{
    res.send(`<h1> THis is home Page </h1>`); 
 })
 


