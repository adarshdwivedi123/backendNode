// import mongoose
const mongose=require('mongoose');
 require("dotenv").config();
const dbConnect=()=>{
    // moongose ka use kr ke database se connect kra  rha hai
    mongose.connect(process.env.DATABASE_URL,{
    })
    // above part is promise
    .then(()=>{
        console.log("Db ka Connection is Succesfull");
    })
    .catch((error)=>{
            console.log("Issue in Db Connection");
            console.log("Isuue in Db Connection");
            console.error(error.message);
            process.exit(1);

    })

} 
    module.exports=dbConnect;
 
