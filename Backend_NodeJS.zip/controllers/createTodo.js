const Todo=require("../models/Todo");

exports.createTodo=async(req,res)=>{
try{
    const {title,price,description}=req.body;
    const response=await Todo.create({title,price,description});
    res.status(200).json({
        success:true,
        data:response,
        message:'Entry Created Successfull'
    })
}
catch(err){
    console.log(err);
    res.status(500)
    .json({
        success:false,
        data:"Internal Servor Error",
        message:err.message,
    })
    
  }
}